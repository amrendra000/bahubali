--     Author: Rodney Shaghoulian
--     Github: github.com/rshaghoulian
-- HackerRank: hackerrank.com/rshaghoulian

SELECT NAME FROM CITY
WHERE COUNTRYCODE = 'JPN';
