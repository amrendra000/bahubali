--     Author: Rodney Shaghoulian
--     Github: github.com/rshaghoulian
-- HackerRank: hackerrank.com/rshaghoulian

SELECT * FROM CITY
WHERE COUNTRYCODE = 'USA' AND POPULATION > 100000;
