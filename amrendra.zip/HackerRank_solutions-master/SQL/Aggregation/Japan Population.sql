--     Author: Rodney Shaghoulian
--     Github: github.com/rshaghoulian
-- HackerRank: hackerrank.com/rshaghoulian

SELECT SUM(POPULATION) FROM CITY
WHERE COUNTRYCODE = 'JPN';
