--     Author: Rodney Shaghoulian
--     Github: github.com/rshaghoulian
-- HackerRank: hackerrank.com/rshaghoulian

SELECT COUNT(*) FROM CITY
WHERE POPULATION > 100000;
