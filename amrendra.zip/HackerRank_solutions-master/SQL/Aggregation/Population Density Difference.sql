--     Author: Rodney Shaghoulian
--     Github: github.com/rshaghoulian
-- HackerRank: hackerrank.com/rshaghoulian

SELECT MAX(POPULATION) - MIN(POPULATION)
FROM CITY;
